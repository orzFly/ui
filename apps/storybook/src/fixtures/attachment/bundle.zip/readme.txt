An archive has no inline preview; the viewer offers a download.
